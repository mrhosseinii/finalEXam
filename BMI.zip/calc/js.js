let display=document.querySelector('#display');
let btnClear=document.querySelector('#btn-clear');
let btnClearLastAction=document.querySelector('#btn-clear-last-action');
let btnBackSpace=document.querySelector('#btn-back-space');

let btnDiv=document.querySelector('#btn-Div');

let btnMul=document.querySelector('#btn-mul');

let btnMinus=document.querySelector('#btn-minus');

let btnPn=document.querySelector('#btn-pn');
let btnPint=document.querySelector('#btn-pint');
let btnPlus=document.querySelector('#btn-plus');
let btnEquls=document.querySelector('#btn-equls');



let btnNumber=document.querySelectorAll('.btn-number')

let setPoint=false;
let setResult=false;

btnClear.addEventListener('click',(e)=>{
display.textContent='0.0';
setPoint=false;
setResult=false;
number1=0;
number2=0;
});
btnBackSpace.addEventListener('click',(e)=>{
let len=display.textContent.length;

let lastDidit=display.textContent.substring(len -1,len);
 if(lastDidit=="."){
    setPoint=false;
 }


if(len >1){
    display.textContent=display.textContent.substring(0,len - 1);
}
else{
    display.textContent="0.0";
}

});
btnPn.addEventListener('click',(e)=>{
    display.textContent=display.textContent *-1;
});

btnPint.addEventListener('click',(e)=>{
    if(setPoint==false){
        display.textContent +='.';
        setPoint=true;
    }
   
});
let number1,number2,result;
let op='';


btnPlus.addEventListener('click',(e)=>{
number1=Number(display.textContent)
display.textContent="0.0";
op="+";
});
btnMinus.addEventListener('click',(e)=>{
    number1=Number(display.textContent)
    display.textContent="0.0";
    op="-";
    })
    btnClearLastAction.addEventListener('click',(e)=>{
        display.textContent='0.0';
      
    })
    btnMul.addEventListener('click',(e)=>{
        number1=Number(display.textContent)
        display.textContent="0.0";
        op="*";
        })
        btnDiv.addEventListener('click',(e)=>{
            number1=Number(display.textContent)
            display.textContent="0.0";
            op="/";
            })

 btnEquls.addEventListener('click',(e)=>{
if(setResult == false){
    number2=Number(display.textContent);
}
else{
    number1=Number(display.textContent);
}

    number2=Number(display.textContent)
      switch(op){
        case "+":
            result=number1 + number2;
            break;
            case "-":
                result=number1 - number2;
                break;
                case "*":
                    result=number1 * number2;
                    break;
                    case "/":
                        result=number1 / number2;
                        break;

      }
      display.textContent=result;
      setResult=true;
    })


btnNumber.forEach((item)=>{
    item.addEventListener('click',(e)=>{
        if(display.textContent =="0.0"){
            display.textContent=e.target.textContent;
        }
        else{
            display.textContent +=e.target.textContent;
        }
        
    })
})